﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
/// <summary>
/// Author : Ayushi Bajpai
/// Modification Date : 08/04/2017
/// Change Description : 
/// </summary>
{
    public partial class CreateLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"];
            }
        }

        protected void CreateLg_Click(object sender, EventArgs e)
        {
            try
            {
                UserMaster Cuser = new UserMaster();
                Cuser.EmployeeID = Convert.ToInt32(txtEmlyID.Text);
                Cuser.UserName = txtUsrName.Text;
                Cuser.Password = txtPswrd.Text;

                int recordsAffected = AdminValidation.CreateLogin(Cuser);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Login Details Created successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Unable to Create the Login details");
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

            //[‎4/‎9/‎2017 10:52 AM] Gupta, Dheeraj: 
            //    Session["User"] = txtUsername.Text;
            //    DataSet ds = new DataSet();
            //    ds.Tables.Add(dt);
            //    Session["Uid"] = ds.Tables[0].Rows[0][0].ToString();
            //    Response.Redirect("/Homepage.aspx"); 

        }

        protected void BackP_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminActivity.aspx");
            
        }
    }
}