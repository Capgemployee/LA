﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    /// <summary>
    /// Author : Ayushi Bajpai
    /// Modification Date : 08/04/2017
    /// Change Description : 
    /// </summary>
    public partial class EmployeeLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {

                if (txtEmpUsrN.Text != "Employee" || txtEmpUsrN.Text != "Employee")
                {
                    throw new AdminException("Invalid Login");
                }
                else
                {
                    Session["Employee"] = txtEmpUsrN.Text;
                    Response.Redirect("EmployeeActivity.aspx");
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                //lblError.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                //lblError.Text = ex.Message;
            }
            
            
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("Welcome.aspx");
        }
    }
}