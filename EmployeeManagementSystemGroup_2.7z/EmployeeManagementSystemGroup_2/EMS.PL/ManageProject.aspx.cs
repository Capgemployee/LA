﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    public partial class ManageProject : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnViewProj_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = AdminValidation.DislpayProjectDetails();
                if (dt.Rows.Count > 0)
                {
                    gvProjectDetails.DataSource = dt;
                    gvProjectDetails.DataBind();
                }
                else
                    throw new EmployeeException("Project Details not Available");
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnAddProj_Click(object sender, EventArgs e)
        {
            try
            {
                Project proj = new Project();
                proj.ProjectID = txtid.Text;
                proj.ProjectName = txtProjectName.Text;
                proj.ClientID = txtClientCode.Text;
                proj.ManagerID = Convert.ToInt32(txtManagerCode.Text);

                int recordsAffected = AdminValidation.AddProjectDetails(proj);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Record added successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Record Not added");
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnAssign_Click(object sender, EventArgs e)
        {
            try
            {
                EmployeeProject proj = new EmployeeProject();
                proj.ProjectID = txtProjectID.Text;
                proj.EmployeeID = Convert.ToInt32(txtEmployeeID.Text);

                int recordsAffected = AdminValidation.AssignProject(proj);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Project Assigned successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Unable to Assign the Project");
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}