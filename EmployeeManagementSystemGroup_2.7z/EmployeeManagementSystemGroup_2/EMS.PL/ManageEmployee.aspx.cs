﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;


namespace EMS.PL
{
    /// <summary>
    /// Author : Ayushi Bajpai
    /// Modification Date : 08/04/2017
    /// Change Description : 
    /// </summary>
    public partial class ManageEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["user"] == null || Session["user"] == String.Empty)
            //{
            //    Response.Redirect("LoginPage.aspx");
            //}
            //else
            //{
            //    lblUser.Text = "Welcome " + Session["user"];
            //}
        }

        protected void btnDeleteEmp_Click1(object sender, EventArgs e)
        {
            try
            {
                int EmpID = Convert.ToInt32(txtEmployeeID.Text);
                int recordsAffected = AdminValidation.DeleteEmployee(EmpID);
                if (recordsAffected != null)
                {
                    Response.Write("<script>alert('Record Deleted successfully')</script>");
                }
                else
                {
                    throw new AdminException("Record NOT Deleted");
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnaddEmp_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee();
                emp.FirstName = txtFirstName.Text;
                emp.LastName = txtLastName.Text;
                emp.DOB = Convert.ToDateTime(txtDOB.Text);
                emp.DOJ = Convert.ToDateTime(txtDOJ.Text);
                emp.Gender = ddlGender.SelectedItem.Text;
                emp.Address = txtAddress.Text;
                emp.MaritalStatus = ddlMStatus.SelectedItem.Text;
                emp.Salary = Convert.ToInt32(txtSalary.Text);
                emp.PhoneNo = txtPhoneNumber.Text;
                emp.DesignationID = ddlDesg.SelectedItem.Text;
                emp.DepartmentID = Convert.ToInt32(ddlDept.SelectedItem.Text);
                emp.ManagerID = Convert.ToInt32(txtMgrCode.Text);
                emp.GradeCode = ddlGradeCode.SelectedItem.Text;


                int recordsAffected = AdminValidation.AddEmployee(emp);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Employee added successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Employee Not added");
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnUpdateEmp_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee();
                emp.EmployeeID = Convert.ToInt32(txtempID.Text);
                emp.FirstName = txtFirstName.Text;
                emp.LastName = txtLastName.Text;
                emp.DOB = Convert.ToDateTime(txtDOB.Text);
                emp.DOJ = Convert.ToDateTime(txtDOJ.Text);
                emp.Gender = ddlGender.SelectedItem.Text;
                emp.Address = txtAddress.Text;
                emp.MaritalStatus = ddlMStatus.SelectedItem.Text;
                emp.Salary = Convert.ToInt32(txtSalary.Text);
                emp.PhoneNo = txtPhoneNumber.Text;
                emp.DesignationID = ddlDesg.SelectedItem.Text;
                emp.DepartmentID = Convert.ToInt32(ddlDept.SelectedItem.Text);
                emp.ManagerID = Convert.ToInt32(txtMgrCode.Text);
                emp.GradeCode = ddlGradeCode.SelectedItem.Text;


                int recordsAffected = AdminValidation.UpdateEmployee(emp);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Employee Updated successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Employee Not Updated");
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void imgbtnUpdate_Click(object sender, ImageClickEventArgs e)
        {
             try
            {
                int empID = Convert.ToInt32(txtempID.Text);
                 DataTable dt = new DataTable();
                 dt = AdminValidation.ViewEmployee(empID);
                if (dt != null)
                {
                    txtFirstName.Text = dt.Rows[0]["FirstName"].ToString();
                    txtLastName.Text = dt.Rows[0]["LastName"].ToString();
                    txtDOB.Text = dt.Rows[0]["DateOfBirth"].ToString();
                    txtDOJ.Text = dt.Rows[0]["DateOfJoining"].ToString();
                    ddlGender.SelectedItem.Text = dt.Rows[0]["Gender"].ToString();
                    txtAddress.Text = dt.Rows[0]["Address"].ToString();
                    ddlMStatus.SelectedItem.Text = dt.Rows[0]["MaritalStatus"].ToString();
                    txtSalary.Text = dt.Rows[0]["Salary"].ToString();
                    txtPhoneNumber.Text = dt.Rows[0]["PhoneNumber"].ToString();
                    ddlDesg.SelectedItem.Text = dt.Rows[0]["DesigCode"].ToString();
                    ddlDept.SelectedItem.Text = dt.Rows[0]["DesigCode"].ToString();
                    txtMgrCode.Text = dt.Rows[0]["MgrID"].ToString();
                    ddlGradeCode.SelectedItem.Text = dt.Rows[0]["GradeCode"].ToString();
                }
                else
                {
                    string message = "Employee not found with this id : " + empID;
                    throw new AdminException(message);
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}