﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    public partial class EmployeeTimeSheet : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnTymShft_Click(object sender, EventArgs e)
        {

            DataTable tbemp = new DataTable();
            int id = Convert.ToInt32(txtTymEmpID.Text);
            tbemp = EmployeeValidation.ViewEmpShift(id);

            txtTymShftID.Text = tbemp.Rows[0]["ShiftID"].ToString();

        }
    }
}