﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;


namespace EMS.PL
{
    /// <summary>
    /// Author : 
    /// Modification Date : 
    /// Change Description : 
    /// </summary>
    public partial class EmployeeProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //lblEmpUser.Text = Session["Employee"].ToString();
            //int UserName = Session["Employee"].ToString();
            //EmployeeValidation empValid = new EmployeeValidation();
            //DataTable table = empValid.viewEmpProfile();

            //if (table != null)
            //{
            //    lblEmplyId.Text = table.Rows[0]["EmpID"].ToString();
            //    lblFirstName.Text = table.Rows[0]["FirstName"].ToString();
            //    lblLastName.Text = table.Rows[0]["LastName"].ToString();
            //    lblDOB.Text = table.Rows[0]["DateOfBirth"].ToString();
            //    lblDOJ.Text = table.Rows[0]["DateOfJoining"].ToString();
            //    lblGender.Text = table.Rows[0]["Gender"].ToString();


            //    lblAddress.Text = table.Rows[0]["Address"].ToString();
            //    lblMstatus.Text = table.Rows[0]["MaritalStatus"].ToString();
            //    lblSal.Text = table.Rows[0]["Salary"].ToString();
            //    lblPhnNumber.Text = table.Rows[0]["PhoneNumber"].ToString();
            //    lblDesg.Text = table.Rows[0]["DesigCode"].ToString();
            //    lblDept.Text = table.Rows[0]["DeptID"].ToString();
            //    lblMgrCode.Text = table.Rows[0]["MgrID"].ToString();
            //    lblGrdCode.Text = table.Rows[0]["GradeCode"].ToString();

            //}
            //else
            //{
            //    Response.Write("Record Not Found");
            //}
        }
    }
}