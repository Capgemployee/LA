﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    /// <summary>
    /// Author : Ayushi Bajpai
    /// Modification Date : 08/04/2017
    /// Change Description : 
    /// </summary>
    public partial class AdminLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Back_Click(object sender, EventArgs e)
        {
            Response.Redirect("Welcome.aspx");
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
   
              if (txtAdmUsrName.Text != "Admin" || txtAdmPswrd.Text != "Admin")
                {
                throw new AdminException("Invalid Login");
                }
             else
                {
                Session["user"] = txtAdmUsrName.Text;
                Response.Redirect("AdminActivity.aspx");
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                //lblError.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                //lblError.Text = ex.Message;
            }
        }
    }
}