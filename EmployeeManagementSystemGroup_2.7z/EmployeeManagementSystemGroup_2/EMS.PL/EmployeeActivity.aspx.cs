﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{  
    /// <summary>
    /// Author : Ayushi Bajpai
    /// Modification Date : 08/04/2017
    /// Change Description : 
    /// </summary>
    public partial class EmployeeActivity : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            //if (Session["Employee"] == null || Session["Employee"] == String.Empty)
            //{
            //    Response.Redirect(".aspx");

            //}
            //else
            //{

            //    lblUser.Text = Session["User"].ToString();
            //}

        }

        protected void btnLogOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("Welcome.aspx");
        }

        protected void btnViePrfl_Click(object sender, EventArgs e)
        {

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {

        }

        protected void btnVieProj_Click(object sender, EventArgs e)
        {

        }

        protected void btnTymShft_Click(object sender, EventArgs e)
        {

        }
    }
}