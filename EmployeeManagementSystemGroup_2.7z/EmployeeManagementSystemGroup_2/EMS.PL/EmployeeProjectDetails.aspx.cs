﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    public partial class EmployeeProjectDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnViewProjectdetails_Click(object sender, EventArgs e)
        {
            try
            {
                string projID = txtProjID.Text;
                DataTable dt = new DataTable();
                dt = EmployeeValidation.SearchProjDetails(projID);
                if (dt != null)
                {
                    gvViewProject.DataSource = dt;
                    gvViewProject.DataBind();
                }
                else
                {
                    string message = "Employee not found with id : " + projID;
                    throw new EmployeeException(message);
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}