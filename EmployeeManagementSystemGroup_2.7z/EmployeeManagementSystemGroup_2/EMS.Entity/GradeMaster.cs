﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Author : Deepak Gupta
    /// Modification Date : 25/03/2017
    /// Change Description : 
    /// </summary>
    public class GradeMaster
    {
        #region Properties

            //Get or Set GradeID
            public string GradeID { get; set; }

            //Get or Set Grade Description
            public string Description { get; set; }

            //Get or Set Minimum salary
            public int MinSalary { get; set; }

            //Get or Set Maximum salary
            public int MaxSalary { get; set; }

        #endregion
    }
}
