﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    /// <summary>
    /// Author : Deepak Gupta
    /// Modification Date : 25/03/2017
    /// Change Description : 
    /// </summary>
    public class ShiftDetail
    {
        #region Properties 

            //Get or Set Shift ID
            public string ShiftID { get; set; }

            //Get or Set shift Name
            public string ShiftName { get; set; }

            //Get or Set Time In
            public DateTime TimeIn { get; set; }

            //Get or Set Time Out
            public DateTime TimeOut { get; set; }

        #endregion
    }
}
