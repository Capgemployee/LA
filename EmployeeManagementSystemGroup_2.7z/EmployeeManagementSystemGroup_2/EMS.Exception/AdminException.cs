﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Exception
{
    /// <summary>
    /// Author : Deepak Gupta
    /// Modification Date : 04/04/2017
    /// Change Description : 
    /// </summary>
    public class AdminException : ApplicationException
    {
        #region Constructors

        public AdminException()
            : base()
        { }

        public AdminException(string message)
            : base(message)
        { }

        #endregion
    }
}
