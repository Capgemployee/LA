﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EMS.Entity;
using EMS.Exception;


namespace EMS.DAL
{
    /// <summary>
    /// Author : Deepak Gupta
    /// Modification Date : 25/03/2017
    /// Change Description : 
    /// </summary>
    public class AdminOperations
    {

        // Admin method: to perform employee functionalities
        // method to add employee
        #region Admin Operation

        public static int AddEmployee(Employee emp)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "Admin_AddEmployee";

                cmd.Parameters.AddWithValue("@FirstName", emp.FirstName);
                cmd.Parameters.AddWithValue("@LastName", emp.LastName);
                cmd.Parameters.AddWithValue("@DateOfBirth", emp.DOB);
                cmd.Parameters.AddWithValue("@DateOfjoining", emp.DOJ);
                cmd.Parameters.AddWithValue("@Gender", emp.Gender);
                cmd.Parameters.AddWithValue("@Address", emp.Address);
                cmd.Parameters.AddWithValue("@MaritalStatus", emp.MaritalStatus);
                cmd.Parameters.AddWithValue("@Salary", emp.Salary);
                cmd.Parameters.AddWithValue("@PhoneNumber", emp.PhoneNo);
                cmd.Parameters.AddWithValue("@DesigCode", emp.DesignationID);
                cmd.Parameters.AddWithValue("@DeptID", emp.DepartmentID);
                cmd.Parameters.AddWithValue("@MgrID", emp.ManagerID);
                cmd.Parameters.AddWithValue("@GradeCode", emp.GradeCode);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //Method to display employee
        public static DataTable DisplayEmployee()
        {
            DataTable dt = new DataTable();

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "Admin_DisplayEmployee";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                }
                else
                {
                    throw new AdminException("Employee Data not available");
                }
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }

            return dt;
        }

        // Method to search employee
        public static Employee SearchEmployee(int empID)
        {
            Employee emp = null;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "Admin_SearchEmployee";

                cmd.Parameters.AddWithValue("@EmpID", empID);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    emp = new Employee();
                    emp.EmployeeID = Convert.ToInt32(dr["EmpID "]);
                    emp.FirstName = dr["FirstName"].ToString();
                    emp.LastName = dr["LastName"].ToString();
                    emp.DOB = Convert.ToDateTime(dr["DateOfBirth"]);
                    emp.DOJ = Convert.ToDateTime(dr["DateOfJoining"]);
                    emp.Gender = dr["Gender"].ToString();
                    emp.Address = dr["Address"].ToString();
                    emp.MaritalStatus = dr["MaritalStatus"].ToString();
                    emp.Salary = Convert.ToInt32(dr["Salary"]);
                    emp.PhoneNo = dr["PhoneNumber"].ToString();
                    emp.DesignationID = dr["DesigCode"].ToString();
                    emp.DepartmentID = Convert.ToInt32(dr["DesigCode"]);
                    emp.ManagerID = Convert.ToInt32(dr["MgrID"]);
                    emp.GradeCode = dr["GradeCode"].ToString();
                }
                else
                {
                    throw new AdminException("Employee not found with id" + empID);
                }
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            return emp;
        }

        //Method to display details in textboxes
        public static DataTable ViewEmployee(int empID)
        {
            DataTable dt = new DataTable();

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();
                cmd.CommandText = "Admin_SearchEmployee";

                cmd.Parameters.AddWithValue("@EmpID", empID);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    Employee emp = new Employee();
                    emp.EmployeeID = Convert.ToInt32(dr["EmpID "]);
                    emp.FirstName = dr["FirstName"].ToString();
                    emp.LastName = dr["LastName"].ToString();
                    emp.DOB = Convert.ToDateTime(dr["DateOfBirth"]);
                    emp.DOJ = Convert.ToDateTime(dr["DateOfJoining"]);
                    emp.Gender = dr["Gender"].ToString();
                    emp.Address = dr["Address"].ToString();
                    emp.MaritalStatus = dr["MaritalStatus"].ToString();
                    emp.Salary = Convert.ToInt32(dr["Salary"]);
                    emp.PhoneNo = dr["PhoneNumber"].ToString();
                    emp.DesignationID = dr["DesigCode"].ToString();
                    emp.DepartmentID = Convert.ToInt32(dr["DesigCode"]);
                    emp.ManagerID = Convert.ToInt32(dr["MgrID"]);
                    emp.GradeCode = dr["GradeCode"].ToString();
                }
                else
                {
                    throw new AdminException("Employee Data not available");
                }
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            return dt;
        }

        // Method to delete employee
        public static int DeleteEmployee(int empID)
        {
            int recordAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "Admin_DeleteEmployee";
                cmd.Parameters.AddWithValue("@EmpID", empID);

                cmd.Connection.Open();
                recordAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {

                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordAffected;

        }

        // Method to update employee
        public static int UpdateEmployee(Employee emp)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "Admin_UpdateEmployee";
                cmd.Parameters.AddWithValue("@EmpID", emp.EmployeeID);
                cmd.Parameters.AddWithValue("@FirstName", emp.FirstName);
                cmd.Parameters.AddWithValue("@LastName", emp.LastName);
                cmd.Parameters.AddWithValue("@DateOfBirth", emp.DOB);
                cmd.Parameters.AddWithValue("@DateOfjoining", emp.DOJ);
                cmd.Parameters.AddWithValue("@Gender", emp.Gender);
                cmd.Parameters.AddWithValue("@Address", emp.Address);
                cmd.Parameters.AddWithValue("@MaritalStatus", emp.MaritalStatus);
                cmd.Parameters.AddWithValue("@Salary", emp.Salary);
                cmd.Parameters.AddWithValue("@PhoneNumber", emp.PhoneNo);
                cmd.Parameters.AddWithValue("@DesigCode", emp.DesignationID);
                cmd.Parameters.AddWithValue("@DeptID", emp.DepartmentID);
                cmd.Parameters.AddWithValue("@MgrID", emp.ManagerID);
                cmd.Parameters.AddWithValue("@GradeCode", emp.GradeCode);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {

                throw ex;
            }
            return recordsAffected;
        }

        // Method to Add Department
        public static int AddDepartment(Department dept)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "Admin_AddDepartment1";

                cmd.Parameters.AddWithValue("@DeptID", dept.DepartmentID);
                cmd.Parameters.AddWithValue("@DeptName", dept.DepartmentName);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();

            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        // Display method for Department
        public static DataTable DislpayDepartment()
        {
            DataTable dt = new DataTable();
            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "Admin_ViewAllDepartment";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                }
                else
                {
                    throw new AdminException("Department Data not Available");
                }
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            return dt;
        }

        // ADMIN'S PROJECT METHODS
        // Method to Add Project
        public static int AddProjectDetails(Project proj)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "Admin_AddProject";

                cmd.Parameters.AddWithValue("@ProjectID", proj.ProjectID);
                cmd.Parameters.AddWithValue("@ProjectName", proj.ProjectName);
                cmd.Parameters.AddWithValue("@ClientCode", proj.ClientID);
                cmd.Parameters.AddWithValue("@MgrID", proj.ManagerID);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        // Display method for Project
        public static DataTable DislpayProjectDetails()
        {
            DataTable dt = new DataTable();
            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "Admin_DisplayProject";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                }
                else
                {
                    throw new AdminException("Project data not available");
                }
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            return dt;
        }

        // Assignment of Project

        public static int AssignProject(EmployeeProject empProj)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "Admin_AssignProject";

                cmd.Parameters.AddWithValue("@ProjectID", empProj.ProjectID);
                cmd.Parameters.AddWithValue("@EmpID", empProj.EmployeeID);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException)
            {
                throw;
            }
            return recordsAffected;
        }

        //ADMIN'S TIMESHEET METHODS
        //Assigment of shift

        public static int AssignShift(EmployeeShiftDetails empShift)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "AssignShiftDetails";

                cmd.Parameters.AddWithValue("@EmpID", empShift.EmployeeID);
                cmd.Parameters.AddWithValue("@ShiftID", empShift.ShiftID);


                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (EmployeeException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            return recordsAffected;

        }

        // Update shift

        public static int UpdateShift(EmployeeShiftDetails empShift)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "UpdateShiftDetails";

                cmd.Parameters.AddWithValue("@ShiftID", empShift.ShiftID);
                cmd.Parameters.AddWithValue("@EmpID", empShift.EmployeeID);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }

            catch (SystemException ex)
            {

                throw ex;
            }
            return recordsAffected;
        }

        // Display shift details
        public static DataTable DislpayTimesheetDetails()
        {
            DataTable dt = new DataTable();
            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "RetrieveShiftDetails";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                }
                else
                {
                    throw new AdminException("Timesheet Details are not available");
                }
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            return dt;
        }

        // SEARCH SHIFT 
        public static EmployeeShiftDetails SearchEmpShift(int empID)
        {
            EmployeeShiftDetails empshft = null;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "RetrieveEmpShftInfo";

                cmd.Parameters.AddWithValue("@EmpID", empID);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    empshft = new EmployeeShiftDetails();
                    empshft.EmployeeID = Convert.ToInt32(dr["EmpID"]);
                    empshft.ShiftID = dr["ShiftID"].ToString();
                }
                else
                {
                    throw new AdminException("Employee shift details not available");
                }
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            return empshft;
        }

        //Login Details
        // Username and Password
        public static int CreateLogin(UserMaster user)
        {
            int recordsAffected = 0;

            try
            {
                SqlCommand cmd = DataConfiguration.CreateCommand();

                cmd.CommandText = "Admin_CreateUser";

                cmd.Parameters.AddWithValue("@EmpID", user.EmployeeID);
                cmd.Parameters.AddWithValue("@Username", user.UserName);
                cmd.Parameters.AddWithValue("@Password", user.Password);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
        #endregion
    }
}
