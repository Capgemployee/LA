﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try 
            {
                User user = new User();
                user.UserName = txtUser.Text;
                user.Password = txtPassword.Text;

                string userName = UserValidation.ValidateUser(user);
                if (userName == null || userName == string.Empty)
                {
                    throw new UserException("User Name/ Password is invalid");
                }
                else
                {
                    Session["user"] = userName;
                    Response.Redirect("DisplayEmployee.aspx");
                }
            }
            catch (UserException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                //lblError.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                //lblError.Text = ex.Message;
            }
        }
    }
}