﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ModelFirstApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        EmpModelContainer employee = new EmpModelContainer();
        EmployeeModel obj;
        
        private void btnsave_Click(object sender, RoutedEventArgs e)
        {
            EmployeeModel obj = new EmployeeModel();
            StringBuilder sb = new StringBuilder();
            bool isNumber;
            int result;
            long contactNo;
            isNumber = int.TryParse(empid.Text, out result);
            if (isNumber)
            {
                //while (isNumber.ToString().Length != 6)
                //{
                //    sb.Append(Environment.NewLine + "Conatct No should consist of 6 digits only.");
                //}
                obj.Empno = result;
            }
            else
            {
                MessageBox.Show("Please enter only numbers in Employee ID field", "Error", MessageBoxButton.OKCancel);
                return;
            }
            obj.Empname = empname.Text;

            obj.EmpDOB = Convert.ToDateTime(empdob.Text);
            obj.EmpDOJ = Convert.ToDateTime(empdoj.Text);
            obj.EmpDesg = empdesg.Text;

            obj.EmpSal = Convert.ToDouble(empsal.Text);

            employee.EmployeeModels.Add(obj);
            employee.SaveChanges();
            MessageBox.Show("Employee Added sucessfully");
            btndeleete.IsEnabled = true;
            empid.Clear();
            empname.Clear();
            empdob.Clear();
            empdoj.Clear();
            empdesg.Clear();
            empsal.Clear();
        }

        private void btnupdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(empid.Text);
                var updatequery = (from eq in employee.EmployeeModels
                                   where eq.Empno == a
                                   select eq).FirstOrDefault();
                if (updatequery != null)
                {
                    obj.Empname = empname.Text;
                    obj.EmpDOB = Convert.ToDateTime(empdob.Text);
                    obj.EmpDOJ = Convert.ToDateTime(empdoj.Text);
                    obj.EmpDesg = empdesg.Text;
                    obj.EmpSal = Convert.ToDouble(empsal.Text);
                    employee.SaveChanges();
                    MessageBox.Show("Employee Updated");
                    empid.Clear();
                    empname.Clear();
                    empdob.Clear();
                    empdoj.Clear();
                    empdesg.Clear();
                    empsal.Clear();

                }
                else
                {
                    MessageBox.Show("Invalid Employee ID");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btndeleete_Click(object sender, RoutedEventArgs e)
        {

            int a = Convert.ToInt32(empid.Text);
            var searchquery = (from eq in employee.EmployeeModels
                               where eq.Empno == a
                               select eq).FirstOrDefault();
            if (searchquery != null)
            {
                obj = searchquery;

                employee.EmployeeModels.Remove(obj);
                employee.SaveChanges();
                MessageBox.Show("Employee Deleted");
            }
            else
            {
                MessageBox.Show("Employee Record not present to be Deleted");
            }
        }

        private void btnsearch_Click(object sender, RoutedEventArgs e)
        {
            int a = Convert.ToInt32(empid.Text);
            var searchquery = (from eq in employee.EmployeeModels
                               where eq.Empno == a
                               select eq).FirstOrDefault();
            if (searchquery != null)
            {
                obj = searchquery;
                empname.Text = obj.Empname;
                empdob.Text = obj.EmpDOB.ToString();
                empdoj.Text = obj.EmpDOJ.ToString();
                empdesg.Text = obj.EmpDesg.ToString();
                empsal.Text = obj.EmpSal.ToString();

            }
            else
            {
                MessageBox.Show("EMPLOYEE NOT FOUND");
            }
        }

        private void btndisplay_Click(object sender, RoutedEventArgs e)
        {
            var query = from a in employee.EmployeeModels
                            select a;
            datagridview.ItemsSource = query.ToList();
            empid.Clear();
        }

        private void btnnew_Click(object sender, RoutedEventArgs e)
        {
            empid.Clear();
            empname.Clear();
            empdob.Clear();
            empdoj.Clear();
            empdesg.Clear();
            empsal.Clear();
        }

        private void datagridview_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void ViewEmp_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
