﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    /// <summary>
    /// Author Name          : Ayushi Bajpai
    /// Creation Date        : 10/04/2017
    /// Description          : Admin Add Project details at the Portal
    /// Last Modified Date   : 10/04/2017
    /// Modified By          : Ayushi Bajpai
    /// Change Description   : No Changes
    public partial class ManageProject : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["user"] == null || Session["user"] == String.Empty)
            //{
            //    Response.Redirect("LoginPage.aspx");
            //}
            //else
            //{
            //    lblUser.Text = "Welcome " + Session["user"];
            //}
        }

        //Display All Project Details
        protected void btnViewProj_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = AdminValidation.DislpayProjectDetails();
                if (dt.Rows.Count > 0)
                {
                    gvProjectDetails.DataSource = dt;
                    gvProjectDetails.DataBind();
                }
                else
                    throw new EmployeeException("Project Details not Available");
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        //Add new Project
        protected void btnAddProj_Click(object sender, EventArgs e)
        {
            try
            {
                Project proj = new Project();
                proj.ProjectID = txtid.Text;
                proj.ProjectName = txtProjectName.Text;
                proj.ClientID = txtClientCode.Text;
                proj.ManagerID = Convert.ToInt32(txtManagerCode.Text);

                int recordsAffected = AdminValidation.AddProjectDetails(proj);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Record added successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Record Not added");
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnAssignProj_Click(object sender, EventArgs e)
        {
            Response.Redirect("AssignProject.aspx");
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminActivity.aspx");
        }
    }
}