﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    /// <summary>
    /// Author Name          : Ayushi Bajpai
    /// Creation Date        : 09/04/2017
    /// Description          : Admin Add and View Departnents
    /// Last Modified Date   : 09/04/2017
    /// Modified By          : Ayushi Bajpai
    /// Change Description   : No Changes
    public partial class ManageDepartment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"];
            }
        }

        //Dipaly All Departments detils in grid view
        protected void btnViewDept_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = AdminValidation.DisplayDepartment();
                if (dt.Rows.Count > 0)
                {
                    gvDept.DataSource = dt;
                    gvDept.DataBind();
                }
                else
                    throw new AdminException("Department Data not Available");
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        //To Add new Department
        protected void btnDept_Click(object sender, EventArgs e)
        {
            try
            {
                Department dept = new Department();
                dept.DepartmentID = Convert.ToInt32(txtDeptId.Text);
                dept.DepartmentName = txtDeptname.Text;

                int recordsAffected = AdminValidation.AddDepartment(dept);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Record added successfully')</script>");
                }
                else
                {
                    throw new AdminException("Record Not added");
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminActivity.aspx");
        }
    }
}