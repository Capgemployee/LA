﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    /// <summary>
    /// Author Name          : Ayushi Bajpai
    /// Creation Date        : 08/04/2017
    /// Description          : This is a Login Page For Admin
    /// Last Modified Date   : 08/04/2017
    /// Modified By          : Ayushi Bajpai
    /// Change Description   : No Changes
    
    public partial class AdminLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //Back to Welcome Page
        protected void Back_Click(object sender, EventArgs e)
        {
            Response.Redirect("Welcome.aspx");
        }

        //Login Validation
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
   
              if (txtAdmUsrName.Text != "Admin" || txtAdmPswrd.Text != "Admin")
                {
                throw new AdminException("Invalid Login");
                }
             else
                {
                Session["user"] = txtAdmUsrName.Text;
                Response.Redirect("AdminActivity.aspx");
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
               
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                
            }
        }
    }
}