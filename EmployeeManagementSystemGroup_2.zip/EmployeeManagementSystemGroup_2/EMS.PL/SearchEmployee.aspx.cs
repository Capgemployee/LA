﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    /// <summary>
    /// Author Name          : Ayushi Bajpai
    /// Creation Date        : 10/04/2017
    /// Description          : For Dispalying all Employee Details and Search the Detail Of Particular Employee
    /// Last Modified Date   : 10/04/2017
    /// Modified By          : Ayushi Bajpai
    /// Change Description   : No Changes
    public partial class SearchEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"];
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminActivity.aspx");
        }

        //Display all employees Detailed Lit
        protected void btnDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = AdminValidation.DisplayEmployee();
                if (dt.Rows.Count > 0)
                {
                    gvDisplay.DataSource = dt;
                    gvDisplay.DataBind();
                }
                else
                    throw new EmployeeException("Employee Data not Available");
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        //Search Button to Search for a particular Employee
        protected void btnSearchEmp_Click(object sender, EventArgs e)
        {
            try
            {
                int empID = Convert.ToInt32(txtSEmpID.Text);
                Employee emp = AdminValidation.SearchEmployee(empID);
                if (emp != null)
                {
                    gvViewEmp.DataSource = new List<Employee> { emp };
                    gvViewEmp.DataBind();
                }
                else
                {
                    string message = "Employee not found with id : " + empID;
                    throw new AdminException(message);
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}