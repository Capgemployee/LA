﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    /// <summary>
    /// Author Name          : Ayushi Bajpai
    /// Creation Date        : 10/04/2017
    /// Description          : Employee Can Search Any Employee to view his/her particular details
    /// Last Modified Date   : 10/04/2017
    /// Modified By          : Ayushi Bajpai
    /// Change Description   : No Changes

    public partial class EmployeeSearch : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Employee"] == null || Session["Employee"] == String.Empty)
            {
                Response.Redirect("EmployeeActivity.aspx");

            }
            else
            {

                lblUser.Text = Session["Employee"].ToString();
            }
        }

        //View Details of Another Employee
        protected void btnEmpDetails_Click(object sender, EventArgs e)
        {
            try
            {
                int empID = Convert.ToInt32(txtEmpID.Text);
                Employee emp = EmployeeValidation.SearchEmployee(empID);
                if (emp != null)
                {
                    txtEmpName.Text = emp.FirstName;
                    txtDesig.Text = emp.DesignationID;
                    txtDepart.Text = emp.DepartmentID.ToString();
                }
                else
                {
                    string message = "Employee not found with id : " + empID;
                    throw new EmployeeException(message);
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("EmployeeActivity.aspx");
        }
    }
}