﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    /// <summary>
    /// Author Name          : Ayushi Bajpai
    /// Creation Date        : 08/04/2017
    /// Description          : Home Page For Employee
    /// Last Modified Date   : 08/04/2017
    /// Modified By          : Ayushi Bajpai
    /// Change Description   : No Changes
    public partial class EmployeeActivity : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["Employee"] == null || Session["Employee"] == String.Empty)
            {
                Response.Redirect("EmployeeActivity.aspx");

            }
            else
            {

                lblUser.Text = Session["Employee"].ToString();
            }

        }
        
        //LogOut button Redirect to Welcome Page
        protected void btnLogOut_Click(object sender, EventArgs e)
        {
            Response.Redirect("Welcome.aspx");
        }

        //Redirect to My Profile Page
        protected void btnViePrfl_Click(object sender, EventArgs e)
        {
            Response.Redirect("EmployeeProfile.aspx");       
        }

        //Redirect To Search Employee Details page
        protected void btnSearch_Click(object sender, EventArgs e)
        {
            Response.Redirect("EmployeeSearch.aspx");          
        }

        //Redirect to view Project details
        protected void btnVieProj_Click(object sender, EventArgs e)
        {
            Response.Redirect("EmployeeProjectDetails.aspx");
        }

        protected void btnTymShft_Click(object sender, EventArgs e)
        {
            Response.Redirect("EmployeeTimeSheet.aspx");   
        }
    }
}