﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;

namespace EMS.PL
{
    /// <summary>
    /// Author Name          : Ayushi Bajpai
    /// Creation Date        : 10/04/2017
    /// Description          : Employee Can View his/her Project Details
    /// Last Modified Date   : 10/04/2017
    /// Modified By          : Ayushi Bajpai
    /// Change Description   : No Changes
    public partial class EmployeeProjectDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Employee"] == null || Session["Employee"] == String.Empty)
            {
                Response.Redirect("EmployeeActivity.aspx");

            }
            else
            {

                lblUser.Text = Session["Employee"].ToString();
            }
        }

        //To view project details in grid
        protected void btnViewProjectdetails_Click(object sender, EventArgs e)
        {
            try
            {
                string projID = txtProjID.Text;
                DataTable dt = new DataTable();
                dt = EmployeeValidation.SearchProjDetails(projID);
                if (dt != null)
                {
                    gvViewProject.DataSource = dt;
                    gvViewProject.DataBind();
                }
                else
                {
                    string message = "Employee not found with id : " + projID;
                    throw new EmployeeException(message);
                }
            }
            catch (EmployeeException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("EmployeeActivity.aspx");
        }
    }
}