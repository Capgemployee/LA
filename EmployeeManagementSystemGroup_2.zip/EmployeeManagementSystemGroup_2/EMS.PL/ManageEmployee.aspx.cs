﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;


namespace EMS.PL
{
    /// <summary>
    /// Author Name          : Ayushi Bajpai
    /// Creation Date        : 08/04/2017
    /// Description          : This page is Contain the Program to Add New Employee
    /// Last Modified Date   : 11/04/2017
    /// Modified By          : Ayushi Bajpai
    /// Change Description   : Add Back Button the Page
    
    public partial class ManageEmployee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"];
            }
        }

        //To Add New Employee
        protected void btnaddEmp_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee();
                emp.FirstName = txtFirstName.Text;
                emp.LastName = txtLastName.Text;
                emp.DOB = Convert.ToDateTime(txtDOB.Text);
                emp.DOJ = Convert.ToDateTime(txtDOJ.Text);
                emp.Gender = ddlGender.SelectedItem.Text;
                emp.Address = txtAddress.Text;
                emp.MaritalStatus = ddlMStatus.SelectedItem.Text;
                emp.Salary = Convert.ToInt32(txtSalary.Text);
                emp.PhoneNo = txtPhoneNumber.Text;
                emp.DesignationID = ddlDesg.SelectedItem.Text;
                emp.DepartmentID = Convert.ToInt32(ddlDept.SelectedItem.Text);
                emp.ManagerID = Convert.ToInt32(txtMgrCode.Text);
                emp.GradeCode = ddlGradeCode.SelectedItem.Text;


                int recordsAffected = AdminValidation.AddEmployee(emp);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Employee added successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Employee Not added");
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        //Back to Home Page Of Admin
        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminActivity.aspx");
        }

        //Redirect To Update Employee Details Page
        protected void btnModify_Click(object sender, EventArgs e)
        {
            Response.Redirect("UpdateEmployee.aspx");
        }
    }
}