﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;


namespace EMS.PL
{
    /// <summary>
    /// Author Name          : Ayushi Bajpai
    /// Creation Date        : 08/04/2017
    /// Description          : Home Page For Admin
    /// Last Modified Date   : 08/04/2017
    /// Modified By          : Ayushi Bajpai
    /// Change Description   : No Changes
    
    public partial class AdminActivity : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null || Session["user"] == String.Empty)
            {
                Response.Redirect("LoginPage.aspx");
            }
            else
            {
                lblUser.Text = "Welcome " + Session["user"];
            }
        }

        //Redirect To Employee Manage Page 
        protected void btnEmpsection_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminEmpManage.aspx");
        }

        //Logout Button:
        protected void btnLogOut_Click(object sender, EventArgs e)
        {

            Response.Redirect("Welcome.aspx");
        }

        //Redirect to Department Management Page
        protected void btnDept_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManageDepartment.aspx");
        }

        //Redirect to Project Management Page
        protected void btnProj_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManageProject.aspx");        
        }

        //Redirect to Create Login Page
        protected void btnCrtLogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("CreateLogin.aspx");
        }

        //Redirect To Time Managemnt Page
        protected void btnTymShft_Click(object sender, EventArgs e)
        {
            Response.Redirect("ManageTimeShift.aspx");
        }
    }
}