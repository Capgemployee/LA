﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using EMS.Entity;
using EMS.Exception;
using EMS.BL;


namespace EMS.PL
{
    /// <summary>
    /// Author Name          : Ayushi Bajpai
    /// Creation Date        : 10/04/2017
    /// Description          : This page is Contain the Program to View his/her own details
    /// Last Modified Date   : 11/04/2017
    /// Modified By          : Ayushi Bajpai
    /// Change Description   : Change in code for Search button
    public partial class EmployeeProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Employee"] == null || Session["Employee"] == String.Empty)
            {
                Response.Redirect("EmployeeActivity.aspx");

            }
            else
            {

                lblEmpUser.Text = Session["Employee"].ToString();
            }
        }

        //To Update Deatils 
        protected void btnEmpUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Employee emp = new Employee();
                emp.EmployeeID = Convert.ToInt32(txtEmpId.Text);
                emp.FirstName = txtEmpFrstName.Text;
                emp.LastName = txtEmpLstName.Text;
                emp.DOB = Convert.ToDateTime(txtEmpDOB.Text);
                emp.Address = txtEmpAdres.Text;
                emp.MaritalStatus = ddlEmpMStatus.SelectedItem.Text;
                emp.PhoneNo = txtEmpPhnNo.Text;

                int recordsAffected = EmployeeValidation.UpdateEmployee(emp);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('Employee Updated successfully')</script>");
                }
                else
                {
                    throw new EmployeeException("Employee Not Updated");
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        //View details in the lables
        protected void imgbtnSearch_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                int empID = Convert.ToInt32(txtEmployeeId.Text);
                Employee emp = AdminValidation.SearchEmployee(empID);
                if (emp != null)
                {
                    lblEmplyId.Text = emp.EmployeeID.ToString();
                    lblFirstName.Text = emp.FirstName;
                    lblLastName.Text = emp.LastName;
                    lblDOB.Text = emp.DOB.ToString();
                    lblDOJ.Text = emp.DOJ.ToString();
                    lblGender.Text = emp.Gender;
                    lblAddress.Text = emp.Address;
                    lblMstatus.Text = emp.MaritalStatus;
                    lblSal.Text = emp.Salary.ToString();
                    lblPhnNumber.Text = emp.PhoneNo;
                    lblDesg.Text = emp.DesignationID;
                    lblDept.Text = emp.DepartmentID.ToString();
                    lblMgrCode.Text = emp.ManagerID.ToString();
                    lblGrdCode.Text = emp.GradeCode;
                }
                else
                {
                    string message = "Employee not found with this id : " + empID;
                    throw new AdminException(message);
                }
            }
            catch (AdminException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("EmployeeActivity.aspx");
        }
    }
}