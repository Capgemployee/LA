﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EMS.Entity;
using EMS.Exception;
using EMS.DAL;


namespace EMS.BL
{
    /// <summary>
    /// Author : Deepak Gupta
    /// Modification Date : 25/03/2017
    /// Change Description : 
    /// </summary>
    public class AdminValidation
    {
        // Admin methods :To perform employee functionalities
        // Method to add employee
        #region Admin

            public static int AddEmployee(Employee emp)
            {
                int recordsAffected = 0;

                try
                {
                    recordsAffected = AdminOperations.AddEmployee(emp);
                }
                catch (AdminException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                return recordsAffected;
            }

            // Method to display employee
            public static DataTable DisplayEmployee()
            {
                DataTable dt = null;

                try
                {
                    dt = AdminOperations.DisplayEmployee();
                }
                catch (AdminException ex)
                {
                    throw ex;
                }

                catch (SystemException ex)
                {
                    throw ex;
                }
                return dt;
            }

            // Method to search employee
            public static Employee SearchEmployee(int empID)
            {
                Employee emp = null;
                try
                {
                    emp = AdminOperations.SearchEmployee(empID);
                }
                catch (AdminException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                return emp;
            }
            
            //Method to view Employee
            public static DataTable ViewEmployee(int empID)
            {
                DataTable dt = null;

                try
                {
                    dt = AdminOperations.ViewEmployee(empID);
                }
                catch (AdminException ex)
                {
                    throw ex;
                }

                catch (SystemException ex)
                {
                    throw ex;
                }
                return dt;
            }
        

            // Method to delete employee
            public static int DeleteEmployee(int empID)
            {
                int recordsAffected = 0;

                try
                {
                    recordsAffected = AdminOperations.DeleteEmployee(empID);
                }
                catch (AdminException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                return recordsAffected;
            }

            // Method to Update employee
            public static int UpdateEmployee(Employee emp)
            {
                int recordsAffected = 0;

                try
                {
                    recordsAffected = AdminOperations.UpdateEmployee(emp);
                }
                catch (AdminException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }

                return recordsAffected;
            }



            // Admin method : to perform operations om department
            // Method to add department
            public static int AddDepartment(Department dept)
            {
                int recordsAffected = 0;

                try
                {
                    recordsAffected = AdminOperations.AddDepartment(dept);
                }
                catch (AdminException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                return recordsAffected;
            }

            // Method to display department
            public static DataTable DisplayDepartment()
            {
                DataTable dt = null;
                try
                {
                    dt = AdminOperations.DislpayDepartment();
                }
                catch (AdminException ex)
                {
                    throw ex;
                }
                catch (SystemException ex)
                {
                    throw ex;
                }
                return dt;
            }

        // Admin methods : to perform operations on project
        // Method to add project
        public static int AddProjectDetails(Project proj)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = AdminOperations.AddProjectDetails(proj);
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        // Method to display project details
        public static DataTable DislpayProjectDetails()
        {
            DataTable dt = null;
            try
            {
                dt = AdminOperations.DislpayProjectDetails();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dt;
        }

        // Method to assign project details
        public static int AssignProject(EmployeeProject empProj)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = AdminOperations.AssignProject(empProj);
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        // Admin method: To perform operations on Timesheet
        // Method to assign timesheet
        public static int AssignShift(EmployeeShiftDetails empShift)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = AdminOperations.AssignShift(empShift);
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        // Method to update timesheet
        public static int UpdateShift(EmployeeShiftDetails empShift)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = AdminOperations.UpdateShift(empShift);
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //3. method to display timesheet
        public static DataTable DislpayTimesheetDetails()
        {
            DataTable dt = null;
            try
            {
                dt = AdminOperations.DislpayTimesheetDetails();
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return dt;
        }

        // Method to search employee's shift
        public static EmployeeShiftDetails SearchEmpShift(int empID)
        {
            EmployeeShiftDetails empshft = null;

            try
            {
                empshft = AdminOperations.SearchEmpShift(empID);
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return empshft;
        }

        // Admin: operation on user master
        // Method to add login details
        public static int CreateLogin(UserMaster user)
        {
            int recordsAffected = 0;
            try
            {
                recordsAffected = AdminOperations.CreateLogin(user);
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
        #endregion
    }
}
