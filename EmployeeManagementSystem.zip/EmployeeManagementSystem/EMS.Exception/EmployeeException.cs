﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Exception
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description : User defined Exception class for Employee
    /// Date of Creation :
    /// </summary>
    public class EmployeeException : ApplicationException
    {
        //Default Constructor
        public EmployeeException()
            : base()
        { }

        //Parameterized Constructor
        public EmployeeException(string message)
            : base(message)
        { }
    }
}
